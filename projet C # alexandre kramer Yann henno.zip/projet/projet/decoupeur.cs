﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Input;

namespace projet
{
    class decoupeur
    {
        string val;
        public List<Soustitres> Soustitres = new List<Soustitres>();

        public decoupeur(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {

                // implémentation du \n qui permet le découpage
                string s;
                val = "";
                while ((s = sr.ReadLine()) != null)
                {
                    val += s + "\n";
                }
            }
           
            int i = 0;

            // découpage des informaton 
            while (i + 1 < val.Length)
            {
                int j = 0;
                string tempsdep = "";
                string tempsfin = "";
                string tempsvalue = "";

                while (val[i] != '\n' && i + 1 < val.Length)
                {
                    i++;
                }
                i++;

                j = i;
                while (val[i] != '\n' && i + 1 < val.Length)
                {
                    if (i - j < 12)
                    {
                        tempsdep += val[i];
                    }
                    else if (-1 < i - (j + 17) && i - (j + 17) < 12)
                    {
                        tempsfin += val[i];
                    }

                    i++;
                }

                i++;

                while ((val[i] != '\n' || val[i + 1] != '\n') && i + 2 < val.Length)
                {

                    tempsvalue += val[i];
                    i++;
                }

                tempsvalue += val[i];

                i++;
                while ((val[i] < '0' || val[i] > '9') && i + 1 < val.Length)
                {
                    i++;
                }


                // Gestion du temps et calcule de la différence

                int h;
                int m;
                int s;
                int ms;


                h = ((tempsdep[0]) * 10) + (tempsdep[1]);
                m = ((tempsdep[3]) * 10) + (tempsdep[4]);
                s = ((tempsdep[6]) * 10) + (tempsdep[7]);
                ms = ((tempsdep[9]) * 100) + ((tempsdep[10]) * 10) + (tempsdep[11]);

                TimeSpan depard = new TimeSpan(0, h, m, s, ms);


                h = ((tempsfin[0]) * 10) + (tempsfin[1]);
                m = ((tempsfin[3]) * 10) + (tempsfin[4]);
                s = ((tempsfin[6]) * 10) + (tempsfin[7]);
                ms = ((tempsfin[9]) * 100) + ((tempsfin[10]) * 10) + (tempsfin[11]);

                TimeSpan fin = new TimeSpan(0, h, m, s, ms);
                TimeSpan difference = fin.Subtract(depard);
                // envoie des information
                Soustitres.Add(new Soustitres(depard, fin, tempsvalue, difference));

            }

            }
    }
}
