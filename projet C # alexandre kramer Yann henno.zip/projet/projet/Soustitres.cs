﻿using System;
using System.Collections.Generic;
using System.Text;

namespace projet
{
    // fait passer les information de program a découpeur
    class Soustitres
    {
        public TimeSpan difference;
        public TimeSpan heuredepard;
        public TimeSpan heurefin;
        public string value;

        public Soustitres(TimeSpan heuredepard, TimeSpan heurefin, string value, TimeSpan dif)
        {
            this.heuredepard = heuredepard;
            this.heurefin = heurefin;
            this.value = value;
            this.difference = dif;
            
        }

    }
}
