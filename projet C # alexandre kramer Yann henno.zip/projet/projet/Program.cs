﻿using System;
using System.Diagnostics;

namespace projet
{
    class Program
    {

        static void Main()

        { // routine de début
            Process.Start(new ProcessStartInfo(@"C:\Program Files\VideoLAN\VLC\vlc.exe"));
            ConsoleColor consoleColor = ConsoleColor.White;
            Start:
            Console.ForegroundColor = ConsoleColor.Magenta;
            System.Console.WriteLine(" ######  ######## ########  ########    ###    ##     ## ########  ########    ###    ########  ######## ########  ");
            Console.ForegroundColor = ConsoleColor.Red;
            System.Console.WriteLine("##    ##    ##    ##     ## ##         ## ##   ###   ### ##     ## ##         ## ##   ##     ## ##       ##     ## ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            System.Console.WriteLine("##          ##    ##     ## ##        ##   ##  #### #### ##     ## ##        ##   ##  ##     ## ##       ##     ## ");
            Console.ForegroundColor = ConsoleColor.Green;
            System.Console.WriteLine(" ######     ##    ########  ######   ##     ## ## ### ## ########  ######   ##     ## ##     ## ######   ########  ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            System.Console.WriteLine("      ##    ##    ##   ##   ##       ######### ##     ## ##   ##   ##       ######### ##     ## ##       ##   ##   ");
            Console.ForegroundColor = ConsoleColor.White;
            System.Console.WriteLine("##    ##    ##    ##    ##  ##       ##     ## ##     ## ##    ##  ##       ##     ## ##     ## ##       ##    ##  ");
            Console.ForegroundColor = ConsoleColor.Blue;
            System.Console.WriteLine(" ######     ##    ##     ## ######## ##     ## ##     ## ##     ## ######## ##     ## ########  ######## ##     ## \n");
            Console.ForegroundColor = ConsoleColor.White;
            System.Console.WriteLine("C-   Demarrer les sous-titres\n");
            System.Console.WriteLine("O-   Options\n");            
            ConsoleKeyInfo saisie = Console.ReadKey(true);
            if (saisie.Key == ConsoleKey.C)
            {
                //lecture des sous titre
                Console.Clear();
                System.Threading.Thread.Sleep(1000);
                // Selection du fichier 
                // !!!!!!! atention vous est deja sur le bureau avec FileFond !!!!!!!! 
                string FileFond = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                FileFond += @"/Rick.srt";
                decoupeur decoupeur = new decoupeur(FileFond);
                int i = 0;
                while (i < decoupeur.Soustitres.Count)
                {
                   

                    Console.ForegroundColor = consoleColor;
                    Console.WriteLine(decoupeur.Soustitres[i].value);
                    i++;
                    System.Threading.Thread.Sleep(decoupeur.Soustitres[i].difference);
                    Console.Clear();


                }
            }
            // choix de la couleur
            if (saisie.Key == ConsoleKey.O)
            {
                Console.WriteLine("Choisir la couleur: Red, Blue, Maganta, Yellow , Cyan");

                string color = Console.ReadLine();

                
                try
                {
                    consoleColor = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), color, true);
                    Console.Clear();
                    goto Start;
                }
                catch (Exception)
                {
                    System.Console.WriteLine("Couleur invalide ");
                    System.Threading.Thread.Sleep(1000);
                    Console.Clear();
                    goto Start;
                }
                Console.ForegroundColor = consoleColor;

                

                


            }
        }
    }
}
